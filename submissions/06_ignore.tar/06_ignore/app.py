print('ready')
